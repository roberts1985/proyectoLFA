from setuptools import setup

setup(
    name="Pythomatas",
    version="1.5",
    description="Paquete que permite realizar múltiples operaciones con autómatas",
    author="Roberto Enrique Alberto Lira, Rubén Armando González García, Víctor Alberto Gómez Pérez, Carlos de Jesús Alberto Lira",
    author_mail="roberto.alberto.lira@gmail.com, applevig@hotmail.com, carlos_alberto-lira@outlook.com",
    scripts=[],
    packages=["Pythomatas"],
    install_requires=["graphviz", "tk"]
)