'''Este es el docstring de mi paquete'''
__all__=[
    'AFN_a_AFD',
    'dibuja_automata_graphviz',
    'reconocedor'
]